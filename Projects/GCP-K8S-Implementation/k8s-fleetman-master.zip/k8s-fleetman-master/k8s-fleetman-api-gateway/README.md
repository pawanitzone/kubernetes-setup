# fleetman-api-gateway

This is not intended to be a full production strength API Gateway. For now it simply serves as a backend facade for the Angular front end to connect to.

In future versions of Fleetman we will introduce a full API Gateway.
