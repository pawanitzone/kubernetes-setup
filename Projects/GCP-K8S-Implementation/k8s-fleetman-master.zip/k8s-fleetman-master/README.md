# k8s Fleetman

***Warning - the heads of each project are just whatever state the project was in when I committed, which includes work in progress (read as: bugs). Use the tags to find the right version of the repo to match your Docker image.***

A new version of "Fleetman", my thrilling example microservice architecture.

This version targets Kubernetes as the orchestration system. We're going to use k8s features to achieve this, whilst simplifying the implementation. Only Hystrix and Feign from NetflixOSS are used.

I'm using the issue tracker to manage the project, check the "Releases" project for progress.
